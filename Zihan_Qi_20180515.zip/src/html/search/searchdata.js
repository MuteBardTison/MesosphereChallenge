var indexSectionsWithContent =
{
  0: "egimpsu",
  1: "es",
  2: "es",
  3: "egimpsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions"
};

